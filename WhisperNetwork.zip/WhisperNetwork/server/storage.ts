import { 
  users, 
  emergencyContacts, 
  sosAlerts, 
  locationShares,
  safetyZones,
  offlineMapData,
  type User, 
  type InsertUser,
  type EmergencyContact,
  type InsertEmergencyContact,
  type SosAlert,
  type InsertSosAlert,
  type LocationShare,
  type InsertLocationShare,
  type SafetyZone,
  type InsertSafetyZone,
  type OfflineMapData,
  type InsertOfflineMapData
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, and } from "drizzle-orm";
import postgres from "postgres";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Emergency contacts
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  deleteEmergencyContact(id: number): Promise<void>;
  
  // SOS alerts
  createSosAlert(alert: InsertSosAlert): Promise<SosAlert>;
  getSosAlerts(userId: number): Promise<SosAlert[]>;
  updateSosAlertStatus(id: number, status: string): Promise<void>;
  
  // Location sharing
  createLocationShare(share: InsertLocationShare): Promise<LocationShare>;
  getLocationShares(userId: number): Promise<LocationShare[]>;
  deleteLocationShare(id: number): Promise<void>;
  
  // Safety zones
  createSafetyZone(zone: InsertSafetyZone): Promise<SafetyZone>;
  getSafetyZones(userId: number): Promise<SafetyZone[]>;
  updateSafetyZone(id: number, updates: Partial<InsertSafetyZone>): Promise<void>;
  deleteSafetyZone(id: number): Promise<void>;
  
  // Offline map data
  saveOfflineMapData(mapData: InsertOfflineMapData): Promise<OfflineMapData>;
  getOfflineMapData(userId: number): Promise<OfflineMapData[]>;
  getOfflineMapByRegion(userId: number, regionName: string): Promise<OfflineMapData | undefined>;
  deleteOfflineMapData(id: number): Promise<void>;
  updateMapLastUsed(id: number): Promise<void>;
}

// Database connection
const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString);
const db = drizzle(client);

export class DatabaseStorage implements IStorage {
  constructor() {
    // Database will be initialized when needed
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    return await db.select().from(emergencyContacts).where(eq(emergencyContacts.userId, userId));
  }

  async createEmergencyContact(insertContact: InsertEmergencyContact): Promise<EmergencyContact> {
    const result = await db.insert(emergencyContacts).values({
      ...insertContact,
      isPrimary: insertContact.isPrimary ?? false
    }).returning();
    return result[0];
  }

  async deleteEmergencyContact(id: number): Promise<void> {
    await db.delete(emergencyContacts).where(eq(emergencyContacts.id, id));
  }

  async createSosAlert(insertAlert: InsertSosAlert): Promise<SosAlert> {
    const result = await db.insert(sosAlerts).values({
      ...insertAlert,
      latitude: insertAlert.latitude ?? null,
      longitude: insertAlert.longitude ?? null
    }).returning();
    return result[0];
  }

  async getSosAlerts(userId: number): Promise<SosAlert[]> {
    return await db.select().from(sosAlerts).where(eq(sosAlerts.userId, userId));
  }

  async updateSosAlertStatus(id: number, status: string): Promise<void> {
    await db.update(sosAlerts).set({ status }).where(eq(sosAlerts.id, id));
  }

  async createLocationShare(insertShare: InsertLocationShare): Promise<LocationShare> {
    const result = await db.insert(locationShares).values({
      ...insertShare,
      sharedWithUserId: insertShare.sharedWithUserId ?? null,
      sharedWithContact: insertShare.sharedWithContact ?? null,
      expiresAt: insertShare.expiresAt ?? null
    }).returning();
    return result[0];
  }

  async getLocationShares(userId: number): Promise<LocationShare[]> {
    return await db.select().from(locationShares).where(eq(locationShares.userId, userId));
  }

  async deleteLocationShare(id: number): Promise<void> {
    await db.delete(locationShares).where(eq(locationShares.id, id));
  }

  async createSafetyZone(insertZone: InsertSafetyZone): Promise<SafetyZone> {
    const result = await db.insert(safetyZones).values(insertZone).returning();
    return result[0];
  }

  async getSafetyZones(userId: number): Promise<SafetyZone[]> {
    return await db.select().from(safetyZones).where(eq(safetyZones.userId, userId));
  }

  async updateSafetyZone(id: number, updates: Partial<InsertSafetyZone>): Promise<void> {
    await db.update(safetyZones).set(updates).where(eq(safetyZones.id, id));
  }

  async deleteSafetyZone(id: number): Promise<void> {
    await db.delete(safetyZones).where(eq(safetyZones.id, id));
  }

  async saveOfflineMapData(insertMapData: InsertOfflineMapData): Promise<OfflineMapData> {
    const result = await db.insert(offlineMapData).values(insertMapData).returning();
    return result[0];
  }

  async getOfflineMapData(userId: number): Promise<OfflineMapData[]> {
    return await db.select().from(offlineMapData).where(eq(offlineMapData.userId, userId));
  }

  async getOfflineMapByRegion(userId: number, regionName: string): Promise<OfflineMapData | undefined> {
    const result = await db.select()
      .from(offlineMapData)
      .where(and(
        eq(offlineMapData.userId, userId),
        eq(offlineMapData.regionName, regionName)
      ))
      .limit(1);
    return result[0];
  }

  async deleteOfflineMapData(id: number): Promise<void> {
    await db.delete(offlineMapData).where(eq(offlineMapData.id, id));
  }

  async updateMapLastUsed(id: number): Promise<void> {
    await db.update(offlineMapData)
      .set({ lastUsed: new Date() })
      .where(eq(offlineMapData.id, id));
  }
}

export const storage = new DatabaseStorage();
