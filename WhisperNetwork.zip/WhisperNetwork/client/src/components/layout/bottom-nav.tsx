import { Home, MapPin, MessageCircle, Users, User } from 'lucide-react';
import { Link, useLocation } from 'wouter';

const navItems = [
  { icon: Home, label: 'Home', path: '/dashboard' },
  { icon: MapPin, label: 'Location', path: '/location' },
  { icon: MessageCircle, label: 'Chat', path: '/chat' },
  { icon: Users, label: 'Contacts', path: '/contacts' },
  { icon: User, label: 'Profile', path: '/profile' },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-gray-700 px-6 py-2">
      <div className="flex justify-around">
        {navItems.map(({ icon: Icon, label, path }) => {
          const isActive = location === path;
          return (
            <Link key={path} href={path} className={`flex flex-col items-center py-2 ${
              isActive ? 'text-safety' : 'text-gray-400 dark:text-gray-500'
            }`}>
              <Icon className="w-5 h-5" />
              <span className="text-xs mt-1 font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
