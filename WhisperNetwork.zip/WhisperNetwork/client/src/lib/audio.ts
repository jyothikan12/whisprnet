export interface FakeCallScript {
  id: string;
  name: string;
  description: string;
  script: string[];
  voice: 'male' | 'female';
  responses: string[][];
}

export const fakeCallScripts: FakeCallScript[] = [
  {
    id: 'dad',
    name: 'Dad',
    description: 'A concerned father checking on you',
    voice: 'male',
    script: [
      "Hi honey, just calling to check on you.",
      "Where are you right now? Can you share your location with me?",
      "I want to make sure you're safe.",
      "Are you with anyone? Do you need me to come pick you up?",
      "Text me your location if you can't talk right now.",
      "I love you, stay safe."
    ],
    responses: [
      ["Hi Dad, I'm okay", "Hey Dad, thanks for checking"],
      ["I'm at [location name]", "I'm downtown right now", "I'm with friends"],
      ["I'm being careful", "Thanks Dad, I appreciate it"],
      ["I'm with some friends", "No, I can get home myself", "Actually yes, can you pick me up?"],
      ["Okay, I'll text you", "Sure thing Dad"],
      ["Love you too Dad", "Thanks, I will"]
    ]
  },
  {
    id: 'police_uncle',
    name: 'Police Uncle',
    description: 'Authoritative police officer',
    voice: 'male',
    script: [
      "Hi, this is Officer Johnson. I'm calling to check on your status.",
      "We received your location ping. Are you in a safe place?",
      "I need you to confirm your current location for me.",
      "If you're in any danger, just say 'yes' and I'll dispatch units immediately.",
      "We're tracking your GPS coordinates. Help is nearby if needed.",
      "Stay on the line with me until you reach a safe location."
    ],
    responses: [
      ["Hello Officer", "Hi, yes this is me"],
      ["Yes, I'm safe now", "I'm in a public place", "I'm okay"],
      ["I'm at [street name]", "I'm near [landmark]", "I'm at the shopping center"],
      ["No, I'm okay now", "Everything's fine", "I don't need help"],
      ["Thank you Officer", "That's reassuring"],
      ["Okay, I understand", "I will, thank you"]
    ]
  },
  {
    id: 'brother',
    name: 'Brother',
    description: 'Protective brother checking in',
    voice: 'male',
    script: [
      "Hey sis, where are you? Mom's worried.",
      "I'm tracking your location. Are you okay?",
      "Do you need me to come get you right now?",
      "If someone's bothering you, just say 'family emergency' and I'll understand.",
      "I'm already in the car. Send me your exact location.",
      "Don't hang up. I'm on my way."
    ],
    responses: [
      ["Hey, I'm fine", "Hi, tell Mom I'm okay"],
      ["Yeah, I'm good", "Everything's fine", "I'm safe"],
      ["No, I can get home", "Actually yes, please come", "I'm okay for now"],
      ["No one's bothering me", "I'm fine, really"],
      ["Okay, I'll send it now", "I'm at [location]"],
      ["Okay, see you soon", "Thanks for coming"]
    ]
  }
];

export class FakeCallAudio {
  private audioContext: AudioContext | null = null;
  private currentScript: FakeCallScript | null = null;
  private isPlaying = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'AudioContext' in window) {
      this.audioContext = new AudioContext();
    }
  }

  async startFakeCall(scriptId: string): Promise<void> {
    const script = fakeCallScripts.find(s => s.id === scriptId);
    if (!script) {
      throw new Error('Script not found');
    }

    this.currentScript = script;
    this.isPlaying = true;

    // Use enhanced speech synthesis for realistic phone call audio
    if ('speechSynthesis' in window) {
      return this.playPreRecordedCall(script);
    } else {
      return this.playWithText(script);
    }
  }

  private async playPreRecordedCall(script: FakeCallScript): Promise<void> {
    const synth = window.speechSynthesis;
    
    // Cancel any existing speech
    synth.cancel();
    
    // Wait for voices to load properly
    let voices = synth.getVoices();
    if (voices.length === 0) {
      await new Promise<void>(resolve => {
        const loadVoices = () => {
          voices = synth.getVoices();
          if (voices.length > 0) {
            resolve();
          }
        };
        synth.addEventListener('voiceschanged', loadVoices);
        setTimeout(() => {
          synth.removeEventListener('voiceschanged', loadVoices);
          resolve();
        }, 2000);
      });
      voices = synth.getVoices();
    }
    
    console.log('Available voices:', voices.map(v => v.name));
    
    // More robust voice selection
    let selectedVoice;
    
    // Try to find the best voice for each character
    if (script.id === 'dad') {
      selectedVoice = voices.find(v => 
        v.name.toLowerCase().includes('male') || 
        v.name.toLowerCase().includes('david') ||
        v.name.toLowerCase().includes('alex')
      );
    } else if (script.id === 'police_uncle') {
      selectedVoice = voices.find(v => 
        v.name.toLowerCase().includes('male') ||
        v.name.toLowerCase().includes('daniel') ||
        v.name.toLowerCase().includes('matthew')
      );
    } else if (script.id === 'brother') {
      selectedVoice = voices.find(v => 
        v.name.toLowerCase().includes('male') ||
        v.name.toLowerCase().includes('tom') ||
        v.name.toLowerCase().includes('mark')
      );
    }
    
    // Fallback voice selection
    if (!selectedVoice) {
      selectedVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
    }
    
    console.log('Selected voice:', selectedVoice?.name);

    // Play each part of the script
    for (let i = 0; i < script.script.length && this.isPlaying; i++) {
      await new Promise<void>((resolve) => {
        const utterance = new SpeechSynthesisUtterance(script.script[i]);
        
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
        
        // Enhanced voice settings for better audibility
        switch (script.id) {
          case 'dad':
            utterance.rate = 0.9;
            utterance.pitch = 1.0;
            utterance.volume = 1.0;
            break;
          case 'police_uncle':
            utterance.rate = 0.95;
            utterance.pitch = 0.8;
            utterance.volume = 1.0;
            break;
          case 'brother':
            utterance.rate = 1.0;
            utterance.pitch = 0.9;
            utterance.volume = 1.0;
            break;
          default:
            utterance.rate = 0.9;
            utterance.pitch = 1.0;
            utterance.volume = 1.0;
        }
        
        this.currentUtterance = utterance;
        
        let hasEnded = false;
        
        utterance.onstart = () => {
          console.log('Speaking:', script.script[i]);
        };
        
        utterance.onend = () => {
          if (!hasEnded) {
            hasEnded = true;
            console.log('Finished speaking:', script.script[i]);
            const pauseDuration = i === 0 ? 2000 : (2500 + Math.random() * 1000);
            setTimeout(resolve, pauseDuration);
          }
        };
        
        utterance.onerror = (event) => {
          console.error('Speech synthesis error:', event);
          if (!hasEnded) {
            hasEnded = true;
            resolve();
          }
        };
        
        // Ensure speech synthesis works
        setTimeout(() => {
          if (!hasEnded) {
            console.log('Force resolving utterance');
            hasEnded = true;
            resolve();
          }
        }, 10000); // 10 second timeout
        
        synth.speak(utterance);
      });
    }
  }

  private async playWithText(script: FakeCallScript): Promise<void> {
    // Fallback: just log the script to console
    console.log(`Fake call from ${script.name}:`);
    for (const line of script.script) {
      console.log(`- ${line}`);
      await new Promise(resolve => setTimeout(resolve, 3000));
      if (!this.isPlaying) break;
    }
  }

  stopFakeCall(): void {
    this.isPlaying = false;
    this.currentScript = null;
    
    // Stop any ongoing speech synthesis
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    
    // Clear current utterance
    if (this.currentUtterance) {
      this.currentUtterance = null;
    }
  }

  isCurrentlyPlaying(): boolean {
    return this.isPlaying;
  }

  getCurrentScript(): FakeCallScript | null {
    return this.currentScript;
  }
}

export const fakeCallAudio = new FakeCallAudio();
