import { ArrowLeft, User, MapPin, Bell, Download, Moon, Lock, HelpCircle, Shield, Info, LogOut } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useAuth } from '@/hooks/use-auth';
import { useTheme } from '@/lib/theme';
import { useToast } from '@/hooks/use-toast';

export default function Profile() {
  const { user, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const { toast } = useToast();

  const handleLogout = () => {
    logout();
    toast({
      title: 'Signed out successfully',
      description: 'You have been safely logged out of WhisprNet.',
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto bg-white dark:bg-slate-800 min-h-screen">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Profile & Settings</h1>
          </div>
          <Button variant="ghost" className="text-safety font-medium">
            Edit
          </Button>
        </div>

        {/* Profile Info */}
        <div className="p-6 pb-24">
          {/* User Card */}
          <div className="bg-gradient-to-r from-safety to-safety-dark rounded-2xl p-6 text-white mb-8 text-center">
            <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl font-bold">
                {user?.fullName?.charAt(0) || 'U'}
              </span>
            </div>
            <h2 className="text-2xl font-bold mb-1">{user?.fullName || 'User'}</h2>
            <p className="text-blue-100 mb-4">{user?.phone || '+1 (555) 000-0000'}</p>
            <div className="flex justify-center space-x-6 text-sm">
              <div>
                <div className="text-2xl font-bold">5</div>
                <div className="text-blue-100">Emergency Contacts</div>
              </div>
              <div>
                <div className="text-2xl font-bold">12</div>
                <div className="text-blue-100">Days Active</div>
              </div>
            </div>
          </div>

          {/* Settings Sections */}
          <div className="space-y-6">
            {/* Safety Settings */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Safety Settings</h3>
              <div className="space-y-3">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-secure" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Location Sharing</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Share location with emergency contacts</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Bell className="w-5 h-5 text-caution" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Emergency Alerts</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Automatic SOS notifications</p>
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Download className="w-5 h-5 text-purple-500" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Offline Maps</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Download maps for offline use</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-safety font-medium text-sm">
                        Manage
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Privacy Settings */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Privacy & Security</h3>
              <div className="space-y-3">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Moon className="w-5 h-5 text-purple-500" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Dark Mode</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">For discreet usage</p>
                        </div>
                      </div>
                      <Switch checked={isDark} onCheckedChange={toggleTheme} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Lock className="w-5 h-5 text-safety" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">App Lock</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Require PIN to open app</p>
                        </div>
                      </div>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* App Settings */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">App Settings</h3>
              <div className="space-y-3">
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <HelpCircle className="w-5 h-5 text-caution" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Help & Support</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">FAQs and contact support</p>
                        </div>
                      </div>
                      <span className="text-gray-400">→</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Shield className="w-5 h-5 text-secure" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">Privacy Policy</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">How we protect your data</p>
                        </div>
                      </div>
                      <span className="text-gray-400">→</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Info className="w-5 h-5 text-safety" />
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">About WhisprNet</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Version 1.0.0</p>
                        </div>
                      </div>
                      <span className="text-gray-400">→</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Logout */}
            <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4" onClick={handleLogout}>
                <div className="flex items-center justify-center space-x-2">
                  <LogOut className="w-5 h-5 text-emergency" />
                  <span className="font-medium text-emergency">Sign Out</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
