import { useState } from 'react';
import { PhoneOff, Phone, MicOff, Volume2, Plus, ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { fakeCallScripts, fakeCallAudio } from '@/lib/audio';

export default function FakeCall() {
  const [isInCall, setIsInCall] = useState(false);
  const [currentCaller, setCurrentCaller] = useState('Dad');
  const [showCallerOptions, setShowCallerOptions] = useState(false);
  const [currentScriptIndex, setCurrentScriptIndex] = useState(0);
  const [showResponses, setShowResponses] = useState(true);
  const { toast } = useToast();

  const handleAnswerCall = async () => {
    setIsInCall(true);
    setCurrentScriptIndex(0);
    
    const script = fakeCallScripts.find(s => s.name === currentCaller);
    if (script) {
      try {
        // Start the actual audio playback
        await fakeCallAudio.startFakeCall(script.id);
        
        // Simulate conversation progression for UI
        const progressConversation = () => {
          if (currentScriptIndex < script.script.length - 1) {
            setTimeout(() => {
              setCurrentScriptIndex(prev => prev + 1);
              progressConversation();
            }, 4000); // Progress every 4 seconds
          } else {
            setTimeout(() => {
              setIsInCall(false);
              toast({
                title: `Fake call from ${currentCaller} completed`,
                description: 'The simulation has ended. You can now safely leave the area.',
              });
            }, 3000);
          }
        };
        
        progressConversation();
      } catch (error) {
        console.error('Failed to start fake call audio:', error);
        toast({
          title: 'Audio Error',
          description: 'Could not start audio. The call will continue silently.',
        });
      }
    }
  };

  const handleEndCall = () => {
    fakeCallAudio.stopFakeCall();
    setIsInCall(false);
  };

  const selectCaller = (callerName: string) => {
    setCurrentCaller(callerName);
    setShowCallerOptions(false);
  };

  const testAudio = async () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance('This is a test of the audio system');
      utterance.volume = 1.0;
      utterance.rate = 1.0;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
      toast({
        title: 'Audio Test',
        description: 'You should hear a test message now.',
      });
    } else {
      toast({
        title: 'Audio Not Supported',
        description: 'Your browser does not support speech synthesis.',
      });
    }
  };

  if (showCallerOptions) {
    return (
      <div className="h-screen bg-gray-900 text-white p-6 pt-16">
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={() => setShowCallerOptions(false)} 
            className="mb-6 p-2 text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h2 className="text-2xl font-bold mb-2">Choose Caller</h2>
          <p className="text-gray-400">Select who should "call" you</p>
        </div>

        <div className="space-y-4">
          {fakeCallScripts.map((script) => (
            <Card key={script.id} className="bg-gray-800 border-gray-700 hover:border-gray-600 cursor-pointer">
              <CardContent className="p-4" onClick={() => selectCaller(script.name)}>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-xl">
                      {script.id === 'police_uncle' ? '👮' : script.id === 'brother' ? '👦' : '👨'}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{script.name}</h3>
                    <p className="text-sm text-gray-400">{script.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-900 text-white flex flex-col">
      {/* Call Header */}
      <div className="p-6 pt-16 text-center">
        <p className="text-sm opacity-60 mb-2">
          {isInCall ? 'In call' : 'Incoming call'}
        </p>
        <h2 className="text-2xl font-semibold mb-1">{currentCaller}</h2>
        <p className="text-sm opacity-80">Mobile +1 (555) 123-4567</p>
        {!isInCall && (
          <div className="space-y-2 mt-2">
            <Button
              variant="link"
              onClick={() => setShowCallerOptions(true)}
              className="text-blue-400 text-sm"
            >
              Change caller
            </Button>
            <br />
            <Button
              variant="link"
              onClick={testAudio}
              className="text-green-400 text-sm"
            >
              Test Audio
            </Button>
          </div>
        )}
      </div>

      {/* Caller Avatar */}
      <div className="flex-1 flex items-center justify-center">
        <div className="w-48 h-48 bg-gray-700 rounded-full flex items-center justify-center mb-8">
          <span className="text-8xl">
            {currentCaller === 'Police Uncle' ? '👮' : currentCaller === 'Brother' ? '👦' : '👨'}
          </span>
        </div>
      </div>

      {/* Conversation Interface */}
      {isInCall && (
        <div className="px-6 mb-6">
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <div className="text-center mb-3">
              <p className="text-sm text-gray-400">What {currentCaller} is saying:</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-3 mb-4">
              <p className="text-white text-center">
                {(() => {
                  const script = fakeCallScripts.find(s => s.name === currentCaller);
                  return script?.script[currentScriptIndex] || "Hello?";
                })()}
              </p>
            </div>
            
            {showResponses && (
              <div>
                <p className="text-sm text-gray-400 mb-2 text-center">Suggested responses:</p>
                <div className="space-y-2">
                  {(() => {
                    const script = fakeCallScripts.find(s => s.name === currentCaller);
                    const responses = script?.responses[currentScriptIndex] || [];
                    return responses.map((response, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="w-full text-left justify-start text-white border-gray-600 hover:bg-gray-600"
                        onClick={() => {
                          // Optional: Add feedback for response selection
                        }}
                      >
                        "{response}"
                      </Button>
                    ));
                  })()}
                </div>
                <Button
                  variant="link"
                  size="sm"
                  className="text-blue-400 text-xs mt-2"
                  onClick={() => setShowResponses(!showResponses)}
                >
                  {showResponses ? 'Hide prompts' : 'Show prompts'}
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Call Controls */}
      <div className="p-8">
        {isInCall ? (
          <>
            {/* In-call Controls */}
            <div className="flex justify-center space-x-12 mb-8">
              <Button variant="secondary" size="lg" className="w-16 h-16 rounded-full bg-gray-700 hover:bg-gray-600">
                <MicOff className="w-6 h-6" />
              </Button>
              <Button variant="secondary" size="lg" className="w-16 h-16 rounded-full bg-gray-700 hover:bg-gray-600">
                <Volume2 className="w-6 h-6" />
              </Button>
              <Button variant="secondary" size="lg" className="w-16 h-16 rounded-full bg-gray-700 hover:bg-gray-600">
                <Plus className="w-6 h-6" />
              </Button>
            </div>

            {/* End Call */}
            <div className="flex justify-center">
              <Button 
                onClick={handleEndCall}
                className="w-20 h-20 bg-emergency rounded-full hover:bg-emergency-dark"
              >
                <PhoneOff className="w-8 h-8" />
              </Button>
            </div>
          </>
        ) : (
          <>
            {/* Answer/Decline */}
            <div className="flex justify-between items-center">
              <Link href="/dashboard">
                <Button className="w-20 h-20 bg-emergency rounded-full hover:bg-emergency-dark">
                  <PhoneOff className="w-8 h-8" />
                </Button>
              </Link>
              <Button 
                onClick={handleAnswerCall}
                className="w-20 h-20 bg-secure rounded-full hover:bg-secure-dark"
              >
                <Phone className="w-8 h-8" />
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
