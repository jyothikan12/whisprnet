import { AlertTriangle, Phone, MapPin, MessageCircle, Users, Check, MapPinIcon, Download } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useAuth } from '@/hooks/use-auth';
import { useGeolocation } from '@/hooks/use-geolocation';

export default function Dashboard() {
  const { user } = useAuth();
  const { latitude, longitude, error } = useGeolocation();

  const locationStatus = error ? 'Offline' : 'Online';
  const locationColor = error ? 'text-red-500' : 'text-secure';

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto bg-white dark:bg-slate-800 min-h-screen">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Dashboard</h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">{user?.fullName || 'User'}</p>
          </div>
          <div className="flex items-center space-x-3">
            {/* Location Status */}
            <div className={`flex items-center space-x-1 ${locationColor}`}>
              <MapPinIcon className="w-4 h-4" />
              <span className="text-xs font-medium">{locationStatus}</span>
            </div>
            {/* Profile */}
            <Link href="/profile">
              <Button variant="secondary" size="sm" className="w-10 h-10 rounded-full p-0">
                <div className="w-full h-full bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center">
                  <span className="text-sm font-medium text-gray-600 dark:text-gray-300">
                    {user?.fullName?.charAt(0) || 'U'}
                  </span>
                </div>
              </Button>
            </Link>
          </div>
        </div>

        {/* Main Content */}
        <div className="px-6 py-6 pb-24">
          {/* Emergency SOS Button */}
          <div className="mb-8">
            <Link href="/sos">
              <Button className="w-full bg-emergency hover:bg-emergency-dark text-white font-bold py-8 px-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 h-auto">
                <div className="flex flex-col items-center">
                  <AlertTriangle className="w-12 h-12 mb-3" />
                  <div className="text-2xl font-bold mb-1">EMERGENCY SOS</div>
                  <div className="text-sm opacity-90">Tap to send immediate alert</div>
                </div>
              </Button>
            </Link>
          </div>

          {/* Quick Actions Grid */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {/* Fake Call */}
            <Link href="/fake-call">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <Phone className="w-8 h-8 text-safety mb-3" />
                  <div className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Fake Call</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Simulate incoming call</div>
                </CardContent>
              </Card>
            </Link>

            {/* Location Tracking */}
            <Link href="/location">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <MapPin className="w-8 h-8 text-secure mb-3" />
                  <div className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Location</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Track & share location</div>
                </CardContent>
              </Card>
            </Link>

            {/* Safety Chat */}
            <Link href="/chat">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <MessageCircle className="w-8 h-8 text-caution mb-3" />
                  <div className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Safety Chat</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">AI safety assistant</div>
                </CardContent>
              </Card>
            </Link>

            {/* Contacts */}
            <Link href="/contacts">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <Users className="w-8 h-8 text-purple-500 mb-3" />
                  <div className="text-sm font-semibold text-gray-900 dark:text-white mb-1">Contacts</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Emergency contacts</div>
                </CardContent>
              </Card>
            </Link>
          </div>

          {/* Safety Status */}
          <Card className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Safety Status</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">All systems operational</p>
                </div>
                <div className="w-12 h-12 bg-secure rounded-full flex items-center justify-center">
                  <Check className="text-white w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-secure">3</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Nearby Users</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secure">5</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Contacts</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-secure">98%</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">Battery</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h3>
            <div className="space-y-3">
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-secure" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Location shared</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">2 hours ago</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                      <Download className="w-5 h-5 text-safety" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Offline map updated</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Yesterday</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
