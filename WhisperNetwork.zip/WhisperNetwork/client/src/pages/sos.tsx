import { useState, useEffect } from 'react';
import { X, MapPin, Users, Shield } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useGeolocation } from '@/hooks/use-geolocation';
import { apiRequest } from '@/lib/queryClient';

export default function SOS() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { latitude, longitude } = useGeolocation();
  const { toast } = useToast();
  const [countdown, setCountdown] = useState(5);
  const [isActive, setIsActive] = useState(true);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (!isActive || countdown <= 0) return;

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          sendEmergencyAlert();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, countdown]);

  const sendEmergencyAlert = async () => {
    if (isSending) return;
    
    setIsSending(true);
    setIsActive(false);

    try {
      await apiRequest('POST', '/api/sos-alerts', {
        userId: user?.id,
        latitude: latitude?.toString(),
        longitude: longitude?.toString(),
      });

      toast({
        title: '🚨 EMERGENCY ALERT SENT!',
        description: 'Location shared with emergency contacts. Authorities notified.',
      });

      // Simulate emergency response
      setTimeout(() => {
        toast({
          title: 'Emergency Response Active',
          description: 'Local authorities have been contacted. Help is on the way.',
        });
      }, 2000);

    } catch (error) {
      toast({
        title: 'Alert Failed',
        description: 'Could not send emergency alert. Please try again.',
        variant: 'destructive',
      });
    }

    setTimeout(() => {
      setLocation('/dashboard');
    }, 3000);
  };

  const cancelAlert = () => {
    setIsActive(false);
    setLocation('/dashboard');
  };

  return (
    <div className="h-screen bg-emergency flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-6 text-white">
        <Button variant="ghost" onClick={cancelAlert} className="p-2 text-white hover:bg-white/20">
          <X className="w-6 h-6" />
        </Button>
        <h1 className="text-xl font-bold">EMERGENCY SOS</h1>
        <div className="w-10"></div>
      </div>

      {/* SOS Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 text-white text-center">
        {/* Countdown Timer */}
        <div className="mb-8">
          <div className="w-48 h-48 border-8 border-white rounded-full flex items-center justify-center mb-6 animate-pulse-red">
            <div>
              <div className="text-6xl font-bold">{countdown}</div>
              <div className="text-lg">seconds</div>
            </div>
          </div>
          <p className="text-xl mb-2">
            {countdown > 0 ? 'Emergency alert will be sent' : 'Sending emergency alert...'}
          </p>
          <p className="text-sm opacity-80">
            {countdown > 0 ? 'Tap Cancel to stop' : 'Please wait...'}
          </p>
        </div>

        {/* Action Buttons */}
        {countdown > 0 && (
          <div className="w-full space-y-4">
            <Button
              onClick={sendEmergencyAlert}
              disabled={isSending}
              className="w-full bg-white text-emergency font-bold py-4 px-6 rounded-xl text-lg hover:bg-gray-100 h-auto"
            >
              {isSending ? 'SENDING...' : 'SEND ALERT NOW'}
            </Button>
            <Button
              onClick={cancelAlert}
              variant="outline"
              className="w-full border-2 border-white text-white font-semibold py-3 px-6 rounded-xl hover:bg-white hover:text-emergency h-auto"
            >
              Cancel
            </Button>
          </div>
        )}

        {/* Features */}
        <div className="mt-8 space-y-2 text-sm opacity-80">
          <div className="flex items-center justify-center space-x-2">
            <MapPin className="w-4 h-4" />
            <span>Current location will be shared</span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <Users className="w-4 h-4" />
            <span>All emergency contacts notified</span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <Shield className="w-4 h-4" />
            <span>Local authorities contacted</span>
          </div>
        </div>
      </div>
    </div>
  );
}
