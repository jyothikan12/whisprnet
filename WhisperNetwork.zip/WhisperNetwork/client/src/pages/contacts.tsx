import { useState } from 'react';
import { ArrowLeft, Plus, Star, Users, Phone, Heart, Shield, UsersRound, Ambulance } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { EmergencyContact } from '@shared/schema';

export default function Contacts() {
  const { user } = useAuth();
  
  const { data: contacts, isLoading } = useQuery<EmergencyContact[]>({
    queryKey: ['/api/emergency-contacts', user?.id],
    enabled: !!user?.id,
  });

  const primaryContacts = contacts?.filter(contact => contact.isPrimary) || [];
  const secondaryContacts = contacts?.filter(contact => !contact.isPrimary) || [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading contacts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto bg-white dark:bg-slate-800 min-h-screen">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Emergency Contacts</h1>
          </div>
          <Button className="w-10 h-10 bg-safety text-white rounded-full flex items-center justify-center">
            <Plus className="w-5 h-5" />
          </Button>
        </div>

        {/* Contacts List */}
        <div className="p-6 pb-24">
          {/* Primary Contacts */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Star className="w-5 h-5 text-caution mr-2" />
              Primary Contacts
            </h3>
            
            {primaryContacts.length > 0 ? (
              <div className="space-y-3">
                {primaryContacts.map((contact) => (
                  <Card key={contact.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                            <Heart className="w-6 h-6 text-emergency" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 dark:text-white">{contact.name}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{contact.phone}</p>
                            <p className="text-xs text-green-600 dark:text-green-400">Will receive immediate SOS alerts</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                          <Phone className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-dashed border-2 border-gray-300 dark:border-gray-600">
                <CardContent className="p-6 text-center">
                  <Heart className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 dark:text-gray-400 text-sm">No primary contacts added yet</p>
                  <Button variant="link" className="text-safety mt-2">
                    Add primary contact
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Secondary Contacts */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Users className="w-5 h-5 text-purple-500 mr-2" />
              Secondary Contacts
            </h3>
            
            {secondaryContacts.length > 0 ? (
              <div className="space-y-3">
                {secondaryContacts.map((contact) => (
                  <Card key={contact.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                            <UsersRound className="w-6 h-6 text-secure" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 dark:text-white">{contact.name}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{contact.phone}</p>
                            <p className="text-xs text-blue-600 dark:text-blue-400">Will receive location updates</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                          <Phone className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-dashed border-2 border-gray-300 dark:border-gray-600">
                <CardContent className="p-6 text-center">
                  <UsersRound className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 dark:text-gray-400 text-sm">No secondary contacts added yet</p>
                  <Button variant="link" className="text-safety mt-2">
                    Add secondary contact
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Emergency Services */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Ambulance className="w-5 h-5 text-emergency mr-2" />
              Emergency Services
            </h3>
            <div className="space-y-3">
              <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-emergency rounded-full flex items-center justify-center">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Emergency Services</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">911</p>
                        <p className="text-xs text-red-600 dark:text-red-400">Automatically contacted during SOS</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-green-600 dark:text-green-400 font-medium">ACTIVE</span>
                      <div className="w-3 h-3 bg-secure rounded-full"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-safety rounded-full flex items-center justify-center">
                        <Shield className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Local Hospital</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">+1 (555) 100-2000</p>
                        <p className="text-xs text-blue-600 dark:text-blue-400">Medical emergency backup</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="text-safety border-safety hover:bg-safety hover:text-white">
                      CALL
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
