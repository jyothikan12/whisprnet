import { ArrowLeft, MapPin, Plus, Minus, Navigation, Download, Route } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BottomNav } from '@/components/layout/bottom-nav';
import { useGeolocation } from '@/hooks/use-geolocation';
import { useToast } from '@/hooks/use-toast';

export default function Location() {
  const { latitude, longitude, accuracy, error } = useGeolocation();
  const { toast } = useToast();

  const shareLocation = () => {
    if (latitude && longitude) {
      toast({
        title: 'Location shared successfully',
        description: 'Your current location has been shared with your emergency contacts.',
      });
    } else {
      toast({
        title: 'Location unavailable',
        description: 'Please enable location services to share your position.',
        variant: 'destructive',
      });
    }
  };

  const downloadMap = () => {
    toast({
      title: 'Downloading offline map',
      description: 'Map data for your current area is being downloaded for offline use.',
    });
  };

  const formatCoordinate = (coord: number | null) => {
    return coord ? coord.toFixed(6) : 'Unknown';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto bg-white dark:bg-slate-800 min-h-screen">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Location Tracking</h1>
          </div>
          <Button onClick={shareLocation} className="px-4 py-2 bg-secure text-white rounded-lg text-sm font-medium">
            Share Location
          </Button>
        </div>

        {/* Map Container */}
        <div className="relative h-80 bg-gray-200 dark:bg-gray-700">
          {/* Map Placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-12 h-12 text-gray-400 dark:text-gray-500 mb-2 mx-auto" />
              <p className="text-gray-600 dark:text-gray-400">Interactive Map</p>
              <p className="text-sm text-gray-500 dark:text-gray-500">
                GPS: {formatCoordinate(latitude)}°, {formatCoordinate(longitude)}°
              </p>
              {error && (
                <p className="text-sm text-red-500 mt-1">{error}</p>
              )}
            </div>
          </div>
          
          {/* Location Pin */}
          {latitude && longitude && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-8 h-8 bg-emergency rounded-full border-4 border-white shadow-lg flex items-center justify-center animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
          )}

          {/* Zoom Controls */}
          <div className="absolute top-4 right-4 flex flex-col space-y-2">
            <Button variant="secondary" size="sm" className="w-10 h-10 rounded-lg shadow-lg">
              <Plus className="w-4 h-4" />
            </Button>
            <Button variant="secondary" size="sm" className="w-10 h-10 rounded-lg shadow-lg">
              <Minus className="w-4 h-4" />
            </Button>
          </div>

          {/* Current Location Button */}
          <Button className="absolute bottom-4 right-4 w-12 h-12 bg-safety text-white rounded-full shadow-lg">
            <Navigation className="w-5 h-5" />
          </Button>
        </div>

        {/* Location Info */}
        <div className="p-6 pb-24">
          {/* Status */}
          <Card className={`mb-6 ${error ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${error ? 'bg-red-500' : 'bg-secure animate-pulse'}`}></div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {error ? 'Location unavailable' : 'Location tracking active'}
                  </span>
                </div>
                <span className="text-xs text-gray-600 dark:text-gray-400">
                  GPS Accuracy: {accuracy ? `${Math.round(accuracy)}m` : 'Unknown'}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center" onClick={downloadMap}>
                <Download className="w-6 h-6 text-safety mx-auto mb-2" />
                <div className="text-sm font-semibold text-gray-900 dark:text-white">Download Map</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Offline access</div>
              </CardContent>
            </Card>
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center">
                <Route className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                <div className="text-sm font-semibold text-gray-900 dark:text-white">Safe Route</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Get directions</div>
              </CardContent>
            </Card>
          </div>

          {/* Shared With */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Sharing Location With</h3>
            <div className="space-y-3">
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                        <span className="text-safety text-sm font-medium">M</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">Mom</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">Active for 2 hours</p>
                      </div>
                    </div>
                    <Button variant="destructive" size="sm" className="text-emergency text-sm">
                      Stop
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                        <span className="text-secure text-sm font-medium">E</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">Emma (Friend)</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">Active for 45 minutes</p>
                      </div>
                    </div>
                    <Button variant="destructive" size="sm" className="text-emergency text-sm">
                      Stop
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Nearby Users */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Nearby WhisprNet Users</h3>
            <div className="space-y-3">
              <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-safety rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">?</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Anonymous User</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">50 meters away</p>
                    </div>
                    <div className="w-3 h-3 bg-secure rounded-full"></div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-safety rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-medium">?</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">Anonymous User</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">120 meters away</p>
                    </div>
                    <div className="w-3 h-3 bg-secure rounded-full"></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
