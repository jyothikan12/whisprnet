import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send, Bot, User } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BottomNav } from '@/components/layout/bottom-nav';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const aiResponses = {
  'feeling unsafe': 'Here are some immediate steps you can take:\n• Stay in well-lit areas\n• Share your location with trusted contacts\n• Use the fake call feature if needed\n• Trust your instincts\n\nWould you like me to activate location sharing or prepare a fake call?',
  'share my location': 'I\'ve activated location sharing with your emergency contacts. They can now see your real-time location. Stay safe!',
  'prepare fake call': 'Fake call is ready! You can trigger it anytime from the dashboard. The call will appear realistic to anyone nearby.',
  'i feel safer now': 'I\'m glad to hear that! Remember, I\'m always here if you need help. Stay alert and trust your instincts.',
  'help': 'I can help you with:\n• Safety tips and advice\n• Activating emergency features\n• Guidance on using the app\n• Support in difficult situations\n\nWhat would you like to know?',
  'default': 'I understand you might be in a stressful situation. How can I help you stay safe right now?'
};

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I\'m your AI safety assistant. I can help you with safety tips, guide you through app features, and provide support in difficult situations. How can I help you today?',
      sender: 'ai',
      timestamp: new Date(Date.now() - 5 * 60 * 1000)
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    for (const [key, response] of Object.entries(aiResponses)) {
      if (key !== 'default' && lowerMessage.includes(key)) {
        return response;
      }
    }
    
    if (lowerMessage.includes('unsafe') || lowerMessage.includes('scared') || lowerMessage.includes('danger')) {
      return aiResponses['feeling unsafe'];
    }
    
    return aiResponses.default;
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: text.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(text),
        sender: 'ai',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const sendQuickResponse = (response: string) => {
    sendMessage(response);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto bg-white dark:bg-slate-800 min-h-screen flex flex-col">
        {/* Header */}
        <div className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-gray-700 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="p-2 text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Safety Assistant</h1>
              <p className="text-sm text-green-600 dark:text-green-400">Online - Ready to help</p>
            </div>
          </div>
          <div className="w-10 h-10 bg-gradient-to-br from-caution to-orange-500 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-6 pb-32 space-y-4 chat-scroll">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.sender === 'user' ? 'justify-end' : ''
              }`}
            >
              {message.sender === 'ai' && (
                <div className="w-8 h-8 bg-gradient-to-br from-caution to-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              
              <div
                className={`rounded-2xl p-4 max-w-xs ${
                  message.sender === 'user'
                    ? 'bg-safety text-white rounded-tr-md'
                    : 'bg-gray-100 dark:bg-slate-700 text-gray-900 dark:text-white rounded-tl-md'
                }`}
              >
                <p className="text-sm whitespace-pre-line">{message.text}</p>
                <span
                  className={`text-xs mt-2 block ${
                    message.sender === 'user'
                      ? 'text-blue-200'
                      : 'text-gray-500 dark:text-gray-400'
                  }`}
                >
                  {formatTime(message.timestamp)}
                </span>
              </div>

              {message.sender === 'user' && (
                <div className="w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-gray-600 dark:text-gray-300" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-caution to-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-gray-100 dark:bg-slate-700 rounded-2xl rounded-tl-md p-4 max-w-xs">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}

          {/* Quick Responses */}
          {messages.length === 1 && (
            <div className="flex flex-wrap gap-2 mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => sendQuickResponse('I\'m feeling unsafe walking alone')}
                className="text-xs"
              >
                I'm feeling unsafe
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => sendQuickResponse('Share my location')}
                className="text-xs"
              >
                Share my location
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => sendQuickResponse('Prepare fake call')}
                className="text-xs"
              >
                Prepare fake call
              </Button>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="fixed bottom-20 left-1/2 transform -translate-x-1/2 w-full max-w-md px-6">
          <div className="bg-white dark:bg-slate-800 border-t border-gray-200 dark:border-gray-700 p-4">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(inputValue);
              }}
              className="flex items-center space-x-3"
            >
              <Input
                type="text"
                placeholder="Type your message..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-2xl bg-gray-50 dark:bg-slate-700 dark:text-white focus:ring-2 focus:ring-safety focus:border-transparent"
              />
              <Button
                type="submit"
                disabled={!inputValue.trim() || isTyping}
                className="w-12 h-12 bg-safety text-white rounded-full flex items-center justify-center hover:bg-safety-dark"
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
          </div>
        </div>

        <BottomNav />
      </div>
    </div>
  );
}
