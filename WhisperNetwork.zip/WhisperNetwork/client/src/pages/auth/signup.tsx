import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';

export default function Signup() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    password: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Create user account
      const userResponse = await apiRequest('POST', '/api/auth/signup', {
        fullName: formData.fullName,
        phone: formData.phone,
        password: formData.password,
      });

      const { user } = await userResponse.json();

      // Add emergency contact if provided
      if (formData.emergencyContactName && formData.emergencyContactPhone) {
        await apiRequest('POST', '/api/emergency-contacts', {
          userId: user.id,
          name: formData.emergencyContactName,
          phone: formData.emergencyContactPhone,
          relationship: 'Emergency Contact',
          isPrimary: true,
        });
      }

      login(user);
      setLocation('/dashboard');
      
      toast({
        title: 'Account created successfully!',
        description: 'Welcome to WhisprNet. Your safety is our priority.',
      });
    } catch (error: any) {
      toast({
        title: 'Signup failed',
        description: error.message || 'Please check your information and try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <div className="max-w-md mx-auto">
        <div className="p-6 pt-16">
          {/* Header */}
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" size="sm" className="mb-6 p-2 text-gray-600 dark:text-gray-300">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Create Account</h2>
            <p className="text-gray-600 dark:text-gray-300">Join our safety community</p>
          </div>
          
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Full Name
              </Label>
              <Input
                type="text"
                placeholder="Enter your full name"
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-slate-700 dark:text-white focus:ring-2 focus:ring-safety focus:border-transparent"
                required
              />
            </div>
            <div>
              <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Phone Number
              </Label>
              <Input
                type="tel"
                placeholder="+1 (555) 000-0000"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-slate-700 dark:text-white focus:ring-2 focus:ring-safety focus:border-transparent"
                required
              />
            </div>
            <div>
              <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Password
              </Label>
              <Input
                type="password"
                placeholder="Create a strong password"
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-slate-700 dark:text-white focus:ring-2 focus:ring-safety focus:border-transparent"
                required
              />
            </div>
            
            {/* Emergency Contact */}
            <Card className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800">
              <CardContent className="p-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                  Primary Emergency Contact
                </h3>
                <div className="space-y-3">
                  <Input
                    type="text"
                    placeholder="Contact name"
                    value={formData.emergencyContactName}
                    onChange={(e) => handleInputChange('emergencyContactName', e.target.value)}
                    className="w-full px-3 py-2 border border-orange-200 dark:border-orange-700 rounded-lg bg-white dark:bg-slate-700 dark:text-white text-sm"
                  />
                  <Input
                    type="tel"
                    placeholder="Contact phone"
                    value={formData.emergencyContactPhone}
                    onChange={(e) => handleInputChange('emergencyContactPhone', e.target.value)}
                    className="w-full px-3 py-2 border border-orange-200 dark:border-orange-700 rounded-lg bg-white dark:bg-slate-700 dark:text-white text-sm"
                  />
                </div>
              </CardContent>
            </Card>
            
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-safety hover:bg-safety-dark text-white font-semibold py-4 px-6 rounded-xl text-lg transition-colors duration-200 h-auto"
            >
              {isLoading ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>
          
          <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-6">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-safety font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
