import { Shield, MapPin, Phone, Users } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Welcome() {
  return (
    <div className="h-screen bg-gradient-to-br from-safety to-safety-dark overflow-hidden relative">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full"></div>
        <div className="absolute top-40 right-5 w-20 h-20 bg-white rounded-full"></div>
        <div className="absolute bottom-40 left-5 w-16 h-16 bg-white rounded-full"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-8 text-center text-white">
        {/* Logo */}
        <div className="mb-8">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-4 mx-auto shadow-2xl">
            <Shield className="text-safety text-4xl w-12 h-12" />
          </div>
          <h1 className="text-4xl font-bold mb-2">WhisprNet</h1>
          <p className="text-xl font-light">Stay Connected. Stay Safe.</p>
        </div>
        
        {/* Features Preview */}
        <div className="mb-12 space-y-4">
          <div className="flex items-center space-x-3">
            <MapPin className="w-6 h-6" />
            <span className="text-lg">Offline Location Tracking</span>
          </div>
          <div className="flex items-center space-x-3">
            <Phone className="w-6 h-6" />
            <span className="text-lg">Emergency SOS Alert</span>
          </div>
          <div className="flex items-center space-x-3">
            <Users className="w-6 h-6" />
            <span className="text-lg">Nearby Safety Network</span>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="w-full space-y-4">
          <Link href="/auth/signup">
            <Button className="w-full bg-white text-safety font-semibold py-4 px-6 rounded-2xl text-lg shadow-lg hover:shadow-xl transition-all duration-200 h-auto">
              Get Started
            </Button>
          </Link>
          <Link href="/auth/login">
            <Button variant="outline" className="w-full border-2 border-white text-white font-semibold py-4 px-6 rounded-2xl text-lg hover:bg-white hover:text-safety transition-all duration-200 h-auto">
              Sign In
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
