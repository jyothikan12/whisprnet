import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  relationship: text("relationship").notNull(),
  isPrimary: boolean("is_primary").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sosAlerts = pgTable("sos_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  status: text("status").notNull().default("active"), // active, resolved, cancelled
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const locationShares = pgTable("location_shares", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  sharedWithUserId: integer("shared_with_user_id"),
  sharedWithContact: text("shared_with_contact"),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const safetyZones = pgTable("safety_zones", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'safe', 'caution', 'danger'
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  radius: integer("radius").notNull(), // in meters
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const offlineMapData = pgTable("offline_map_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  regionName: text("region_name").notNull(),
  centerLatitude: text("center_latitude").notNull(),
  centerLongitude: text("center_longitude").notNull(),
  zoomLevel: integer("zoom_level").notNull(),
  boundingBox: text("bounding_box").notNull(), // JSON string with northeast/southwest bounds
  mapTiles: text("map_tiles").array(), // Array of tile URLs or data
  downloadedAt: timestamp("downloaded_at").defaultNow().notNull(),
  lastUsed: timestamp("last_used").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  fullName: true,
  phone: true,
  password: true,
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).pick({
  userId: true,
  name: true,
  phone: true,
  relationship: true,
  isPrimary: true,
});

export const insertSosAlertSchema = createInsertSchema(sosAlerts).pick({
  userId: true,
  latitude: true,
  longitude: true,
});

export const insertLocationShareSchema = createInsertSchema(locationShares).pick({
  userId: true,
  sharedWithUserId: true,
  sharedWithContact: true,
  latitude: true,
  longitude: true,
  expiresAt: true,
});

export const insertSafetyZoneSchema = createInsertSchema(safetyZones).pick({
  userId: true,
  name: true,
  type: true,
  latitude: true,
  longitude: true,
  radius: true,
  description: true,
  isActive: true,
});

export const insertOfflineMapDataSchema = createInsertSchema(offlineMapData).pick({
  userId: true,
  regionName: true,
  centerLatitude: true,
  centerLongitude: true,
  zoomLevel: true,
  boundingBox: true,
  mapTiles: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertSosAlert = z.infer<typeof insertSosAlertSchema>;
export type SosAlert = typeof sosAlerts.$inferSelect;
export type InsertLocationShare = z.infer<typeof insertLocationShareSchema>;
export type LocationShare = typeof locationShares.$inferSelect;
export type InsertSafetyZone = z.infer<typeof insertSafetyZoneSchema>;
export type SafetyZone = typeof safetyZones.$inferSelect;
export type InsertOfflineMapData = z.infer<typeof insertOfflineMapDataSchema>;
export type OfflineMapData = typeof offlineMapData.$inferSelect;
